# SketchUp Icon Repair for Mac

For years, SketchUp icons on the Mac have sometimes appeared as generic file icons, without the model image preview that makes a large library usable. This package restores those previews as Finder icons.

It contains two complementary tools:

- **SketchUp Icon Keeper.rbz** keeps newly saved models discoverable. Install it once in SketchUp and it automatically restores the Finder icon after saving a `.skp` file. SketchUp's `~.skp` backup files preserve the same custom icon when they are created.
- **SketchUp Icon Repair.app** repairs an existing library. Choose a folder and it finds every `.skp` file below it, extracts the embedded thumbnail, and writes it as that file's Finder icon.

## Install the automatic SketchUp extension

1. In SketchUp, open **Extension Manager**.
2. Click **Install Extension** and choose `SketchUp Icon Keeper.rbz` from this package.
3. Enable **SketchUp Icon Keeper** if asked, then restart SketchUp.

From then on, the plugin works after an ordinary save. It also adds **Extensions > Repair current SketchUp Finder icon** for repairing the current file immediately.

The extension is unsigned, so SketchUp will identify it as such. That is expected for this independently distributed extension.

## Repair an existing library

1. Double-click **SketchUp Icon Repair.app**.
2. Choose your user, project, or model-library folder — **not Macintosh HD**.
3. Click **Start Repair**.

The app scans normal subfolders on the selected volume, skips application/library packages such as Lightroom preview caches, and opens only `.skp` files. It may ask macOS for access to protected folders. A running report named `SketchUp Icon Repair - DeleteMe.txt` is written in the folder you selected; delete it whenever you no longer need it. Use **Stop** to end a run.

## What changes

The tools read the model's existing embedded thumbnail (`meta/model_thumbnail.png`). They do not render the model, alter model geometry, or rewrite `.skp` contents. They add macOS Finder custom-icon metadata, and preserve each model file's modification and access times.

## Notes

- This package is for macOS.
- The folder-repair app uses macOS's `python3` command. If it reports that Python 3 is missing, install Python 3 and run the app again.
- If macOS warns before opening the helper app, Control-click it and choose **Open**.
- A model must contain SketchUp's embedded thumbnail to receive an icon.
- Version 1.0.1 / SketchUp Icon Keeper 0.1.2
